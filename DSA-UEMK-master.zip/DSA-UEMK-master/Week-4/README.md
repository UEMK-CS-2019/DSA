<p align="center">
 <img width="200px" src="https://github.com/xiaowuc2/xiaowuc2/blob/master/source/5.jpg" align="center" />
 <h2 align="center">DSA | Week-4</h2>
 <h4 align="center">Python + video tutorial <img width="25px" src="https://github.com/xiaowuc2/All-readme-templates/blob/master/sources/compass.png" align="center"/></h4></p>
</p>
  <p align="center">

[.](https://github.com/xiaowuc2/Research/blob/master/README.md)

<img width="40px" src="https://github.com/xiaowuc2/xiaowuc2/blob/master/source/download.png" align="center"/> Challanege is Active on [**Hackerrank**](https://www.hackerrank.com/contests/ds-algo-lab-week-4/challenges) `06/07/20`


[.](https://github.com/xiaowuc2/Research/blob/master/README.md)


### Question Overview <img width="25px" src="https://github.com/xiaowuc2/All-readme-templates/blob/master/sources/overview.jpg" align="center"/>

[.](https://github.com/xiaowuc2/Research/blob/master/README.md)
