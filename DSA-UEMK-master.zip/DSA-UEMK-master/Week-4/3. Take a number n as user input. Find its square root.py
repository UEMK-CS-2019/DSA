number = int(input( ))
sqrt = number ** 0.5
print(int(sqrt))
