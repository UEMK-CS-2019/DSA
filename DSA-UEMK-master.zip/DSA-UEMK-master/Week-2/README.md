<p align="center">
 <img width="200px" src="https://github.com/xiaowuc2/xiaowuc2/blob/master/source/5.jpg" align="center" />
 <h2 align="center">DSA | Week-2</h2>
 <h4 align="center">C + video tutorial <img width="25px" src="https://github.com/xiaowuc2/All-readme-templates/blob/master/sources/compass.png" align="center"/></h4></p>
</p>
  <p align="center">

[.](https://github.com/xiaowuc2/Research/blob/master/README.md)

<img width="40px" src="https://github.com/xiaowuc2/xiaowuc2/blob/master/source/download.png" align="center"/> Challanege is Active on [**Hackerrank**](https://www.hackerrank.com/contests/ds-algo-lab-week-2/challenges) `13/07/20`


<img width="45px" src="https://github.com/xiaowuc2/xiaowuc2/blob/master/source/Graphic_Designe.png" align="center"/> **Solution** `PDF` [**Google Drive**](https://drive.google.com/file/d/1ZBnpmhc_ZpRjkpPOOqGLysQGnDVtkd4G/view?usp=sharing)

[.](https://github.com/xiaowuc2/Research/blob/master/README.md)


### Question Overview <img width="25px" src="https://github.com/xiaowuc2/All-readme-templates/blob/master/sources/overview.jpg" align="center"/>

[.](https://github.com/xiaowuc2/Research/blob/master/README.md)
