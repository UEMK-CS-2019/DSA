string=input("")
string=string.replace('the','THE')
print(string)
