s=input()
a=s.strip()
print(a)
