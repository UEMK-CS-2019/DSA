string=input()
start=int(input())
end=int(input())
print(string[start:end+1])
