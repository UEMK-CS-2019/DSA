pi = 3.14
r = 6
a = 4/3
v = a*pi*r*r*r
print ("{:.2f}".format(v))
