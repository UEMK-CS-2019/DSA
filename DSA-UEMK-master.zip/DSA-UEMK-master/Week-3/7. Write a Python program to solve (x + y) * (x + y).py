x=int(input())
y=int(input())
a= ((x+y)**2)
print(a)
