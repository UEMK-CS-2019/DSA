a=int(input())
if a%2==0:
    print("the given no is even")
else: 
    print("the given no is odd")
