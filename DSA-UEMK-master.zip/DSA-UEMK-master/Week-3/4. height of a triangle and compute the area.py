b=int(input())
h=int(input())
p=0.5*b*h
q=int(p)
print("area = {}".format(q))
