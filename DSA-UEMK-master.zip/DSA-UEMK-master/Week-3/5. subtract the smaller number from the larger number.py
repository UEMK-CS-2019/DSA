a=int(input())
b=int(input())
if a>b:
    print(a-b)
else:
    print(b-a)
