r=int(input())
pi=3.14
r=(pi*(r*r))
print("area = "+ str(r))
